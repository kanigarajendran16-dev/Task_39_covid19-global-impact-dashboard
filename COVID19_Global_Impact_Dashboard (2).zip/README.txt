COVID-19 Global Impact Dashboard - Day 39
Tools: Python, Pandas, NumPy, Matplotlib, Plotly, Excel, ReportLab
Outputs: cleaned CSV, Excel workbook, interactive HTML, PDF and PNG charts
Dataset source used: https://raw.githubusercontent.com/owid/covid-19-data/master/public/data/owid-covid-data.csv
Please check the PDF for assumptions and limitations.
